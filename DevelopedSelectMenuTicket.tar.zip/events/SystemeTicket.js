const {Permissions, MessageEmbed, MessageActionRow, MessageSelectMenu }=require('discord.js')
module.exports = {
    name: 'interactionCreate',
    async execute(client, interaction) {
        if (!interaction.isSelectMenu()) return;
        
	const row = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                    .setCustomId('del')
                    .setPlaceholder('قم بالاختيار من هنا لحذف التذكرة !')
					.addOptions([
						{
							label: 'خذف التذكرة',
							description: 'القيام بحذف الغرفة',
							value: 'delete',
						}
					])
                );
                
                
        let catégorie = "1177805493100609537"
        let roleStaff = interaction.guild.roles.cache.get('1177703363576610926')

        let DejaUnChannel = interaction.guild.channels.cache.find(c => c.topic == interaction.user.id)
        
        if(interaction.customId === "del") {
            if (interaction.values[0] == "delete") {
                const channel = interaction.channel
                channel.delete();
            }
        }

        if (interaction.customId == "select") {
            if (DejaUnChannel) return interaction.reply({content: 'لديك تذكرة قيد المعالجة بالفعل.', ephemeral: true})
            if (interaction.values[0] == "partenariat") {
                interaction.guild.channels.create(`ticket of ${interaction.user.username}`, {
                    type: 'GUILD_TEXT',
                    topic: `${interaction.user.id}`,
                    parent: `${catégorie}`,
                    permissionOverwrites: [
                        {   
                            id: interaction.guild.id,
                            deny: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: interaction.user.id,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: roleStaff,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        }
                    ]
                }).then((c)=>{
                    const partenariat = new MessageEmbed()
                    .setTitle('تذكرة للاستفسار')
                    .setDescription('يرجى تفصيل طلبك لمشرف الخادم ليقدمه لك برعاية تامة .')
                    .setFooter('Tunesy Support')
                    c.send({embeds: [partenariat], content: `${roleStaff} | ${interaction.user}`, components: [row]})
                    interaction.reply({content: `تم فتح التذكرة بنجاح في : <#${c.id}>`, ephemeral: true})
                })
                
            } else if (interaction.values[0] == "plainte") {
                interaction.guild.channels.create(`ticket of ${interaction.user.username}`, {
                    type: 'GUILD_TEXT',
                    topic: `${interaction.user.id}`,
                    parent: `${catégorie}`,
                    permissionOverwrites: [
                        {   
                            id: interaction.guild.id,
                            deny: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: interaction.user.id,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: roleStaff,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        }
                    ]
                }).then((c)=>{
                    const plainte = new MessageEmbed()
                    .setTitle('تذكرة شراء بوتات')
                    .setDescription('يرجى تفصيل طلبك لمشرف الخادم ليقدمه لك برعاية تامة .')
                    .setFooter('Tunesy Support')
                    c.send({embeds: [plainte], content: `${roleStaff} | ${interaction.user}`, components: [row]})
                    interaction.reply({content: ` تم فتح التذكرة بنجاح في : <#${c.id}>`, ephemeral: true})
                })
            } else if (interaction.values[0] == "recrutement") {
                interaction.guild.channels.create(`ticket of ${interaction.user.username}`, {
                    type: 'GUILD_TEXT',
                    topic: `${interaction.user.id}`,
                    parent: `${catégorie}`,
                    permissionOverwrites: [
                        {   
                            id: interaction.guild.id,
                            deny: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: interaction.user.id,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        },
                        {
                            id: roleStaff,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL]
                        }
                    ]
                }).then((c)=>{
                    const embed = new MessageEmbed()
                    .setTitle('تذكرة تبليغ عن خطأ فني')
                    .setDescription('الرجاء ذكر الخطأ و تقديم بعض الصور عنه ليقوم المسؤول عن الخادم بمساعدتك باكمل وجه .')
                    .setFooter('Tunesy Support')
                    c.send({embeds: [embed], content: `${roleStaff} | ${interaction.user}`, components: [row]})
                    interaction.reply({content:`تم فتح التذكرة بنجاح في : <#${c.id}>`, ephemeral: true})
                })
                
            
                
            
            }
        }
    }
}
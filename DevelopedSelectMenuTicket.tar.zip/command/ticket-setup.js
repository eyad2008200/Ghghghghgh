const {MessageActionRow, MessageSelectMenu} = require('discord.js')
module.exports = {
    name: 'ticket',
    usage: 'template',
    category: "mod",
    description: `Commande template.`,
    async execute(client, message, args) {
		message.delete()
        const row = new MessageActionRow()
			.addComponents(
				new MessageSelectMenu()
					.setCustomId('select')
					.setPlaceholder('قم بالاخيار من هنا.')
					.addOptions([
						{
							label: 'استفسار',
							description: 'اضغط هنا لفتح تذكرة استفسار',
							value: 'partenariat',
						},
						{
							label: 'شراء بوتات',
							description: 'اضغط هنا لفتح تذكرة شراء بوتات',
                           value: 'plainte',
						},
                        {
							label: 'خطأ فني',
							description: 'اضغط هنا لفتح تذكرة تبليغ تن خطأ فني',
							value: 'recrutement',
						},
					]),
			);

        message.channel.send({
            embeds: [{
                title: 'فتح تذكرة خاصة.',
                description: `ملاحظات مهمة قبل فتح التذكرة 

- الدفع مُسبق قبل البدء في العمل.
- بمجرد دفع المبلغ لايمكنك الغاء الطلب.
- منعًا للاحراج ليس هُنالك خدمة مجانية.
- المتجر غير مسؤول عن أي مشكله في الدفع.`,
                color: "DARK_BUT_NOT_BLACK",
                footer: {text: 'Tunesy Ticket Bot ©'},
                image: { url: 'https://i.imgur.com/myBBU3W.jpg' }
            }],
            components: [row]
        })
    }
}
